package org.boilit.bsl.xtc;

/**
 * @author Boilit
 * @see
 */
public interface ITextCompressor {

    public String doCompress(String value);
}
