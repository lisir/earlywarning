package org.boilit.bsl.core;

/**
 * @author Boilit
 * @see
 */
public abstract class AbstractStructure extends AbstractExpression {
    public AbstractStructure(final int line, final int column) {
        super(line, column);
    }
}
