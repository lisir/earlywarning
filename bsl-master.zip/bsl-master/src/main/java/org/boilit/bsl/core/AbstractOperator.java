package org.boilit.bsl.core;

/**
 * @author Boilit
 * @see
 */
public abstract class AbstractOperator extends AbstractExpression {
    public AbstractOperator(final int line, final int column) {
        super(line, column);
    }
}
